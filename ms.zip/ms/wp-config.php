<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'onezikoc_wp78' );

/** MySQL database username */
define( 'DB_USER', 'onezikoc_wp78' );

/** MySQL database password */
define( 'DB_PASSWORD', '9X9gSn(!p3' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'ggywujvilk2xqhj5761shxczg2gwy18gccloamxwr0b8yhcaloj5za5ol7abd5vk' );
define( 'SECURE_AUTH_KEY',  'zx41bcautukznmbxvdppzwnnnd7p1mz3kvjbbq5wtsfein3fguomqe5kp9w7zshx' );
define( 'LOGGED_IN_KEY',    'wiu3djbdlhyialjacua55i1ptbt7hxpgsx7xws2qedm2fhh4bwqcevrcxucdvd2i' );
define( 'NONCE_KEY',        'rm7gewyqgiuxxrmhmey01awvzmimtxnzos0ofeowbp1bikd3pmsqguu6xzgddjib' );
define( 'AUTH_SALT',        'zqd1lbr1tlbik1xowfdrowzqos6fcnvrp7xa6knjjemrseojrivjrminlrspump0' );
define( 'SECURE_AUTH_SALT', 'zwv0n8jiv5cekhx3ny7svwqglgat3uskgndcfj9awivlo50zu4pf7nrdi1djrrw7' );
define( 'LOGGED_IN_SALT',   'iu5f6argb9yh2mjb2tbyyy8j3pyoyoliqrfoowcs7z8xcnnx2wtgmzq03bpunpeu' );
define( 'NONCE_SALT',       '0mrx18nxovxnxrbaxok4l51snmevzc5ifh5kpgldixgbxxtvjgfgkj6twju7ozrs' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpdk_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
